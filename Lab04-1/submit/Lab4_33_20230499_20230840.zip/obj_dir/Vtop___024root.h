// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vtop.h for the primary calling header

#ifndef VERILATED_VTOP___024ROOT_H_
#define VERILATED_VTOP___024ROOT_H_  // guard

#include "verilated.h"


class Vtop__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vtop___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(reset,0,0);
        VL_OUT8(is_halted,0,0);
        CData/*0:0*/ top__DOT__reset;
        CData/*0:0*/ top__DOT__clk;
        CData/*0:0*/ top__DOT__is_halted;
        CData/*0:0*/ top__DOT__cpu__DOT__reset;
        CData/*0:0*/ top__DOT__cpu__DOT__clk;
        CData/*0:0*/ top__DOT__cpu__DOT__is_halted;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_ctrl_alu_op;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_alu_src;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_mem_write;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_mem_read;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_mem_to_reg;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_reg_write;
        CData/*4:0*/ top__DOT__cpu__DOT__ID_EX_rd;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_mem_write;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_mem_read;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_is_branch;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_mem_to_reg;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_reg_write;
        CData/*4:0*/ top__DOT__cpu__DOT__EX_MEM_rd;
        CData/*0:0*/ top__DOT__cpu__DOT__MEM_WB_mem_to_reg;
        CData/*0:0*/ top__DOT__cpu__DOT__MEM_WB_reg_write;
        CData/*0:0*/ top__DOT__cpu__DOT__IF_PCsrc;
        CData/*4:0*/ top__DOT__cpu__DOT__ID_rs1;
        CData/*4:0*/ top__DOT__cpu__DOT__ID_rs2;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_mem_read;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_mem_to_reg;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_mem_write;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_alu_src;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_write_enable;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_pc_to_reg;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_alu_op;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_is_ecall;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_ctrl_branch;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_is_halted;
        CData/*0:0*/ top__DOT__cpu__DOT__PC_Write;
        CData/*0:0*/ top__DOT__cpu__DOT__IF_ID_Write;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_CtrlUnitMux_sel;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_branch;
        CData/*4:0*/ top__DOT__cpu__DOT__ID_EX_rs1;
        CData/*4:0*/ top__DOT__cpu__DOT__ID_EX_rs2;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_is_halted;
        CData/*0:0*/ top__DOT__cpu__DOT__ID_EX_ctrl_is_ecall;
        CData/*7:0*/ top__DOT__cpu__DOT__EX_alu_op;
        CData/*1:0*/ top__DOT__cpu__DOT__forward_a;
        CData/*1:0*/ top__DOT__cpu__DOT__forward_b;
        CData/*0:0*/ top__DOT__cpu__DOT__forward_ecall;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_alu_bcond;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_bcond;
        CData/*0:0*/ top__DOT__cpu__DOT__EX_MEM_is_halted;
        CData/*4:0*/ top__DOT__cpu__DOT__MEM_WB_rd;
        CData/*0:0*/ top__DOT__cpu__DOT__MEM_WB_is_halted;
        CData/*0:0*/ top__DOT__cpu__DOT__PC_mux__DOT__sel;
        CData/*0:0*/ top__DOT__cpu__DOT__pc__DOT__reset;
        CData/*0:0*/ top__DOT__cpu__DOT__pc__DOT__clk;
        CData/*0:0*/ top__DOT__cpu__DOT__pc__DOT__PC_Write;
        CData/*0:0*/ top__DOT__cpu__DOT__imem__DOT__reset;
        CData/*0:0*/ top__DOT__cpu__DOT__imem__DOT__clk;
        CData/*0:0*/ top__DOT__cpu__DOT__reg_file__DOT__reset;
        CData/*0:0*/ top__DOT__cpu__DOT__reg_file__DOT__clk;
        CData/*4:0*/ top__DOT__cpu__DOT__reg_file__DOT__rs1;
        CData/*4:0*/ top__DOT__cpu__DOT__reg_file__DOT__rs2;
    };
    struct {
        CData/*4:0*/ top__DOT__cpu__DOT__reg_file__DOT__rd;
        CData/*0:0*/ top__DOT__cpu__DOT__reg_file__DOT__write_enable;
        CData/*6:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__Instr;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__MemRead;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__MemtoReg;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__MemWrite;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__ALUSrc;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__RegWrite;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__PCtoReg;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__alu_op;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__Branch;
        CData/*0:0*/ top__DOT__cpu__DOT__ctrl_unit__DOT__is_ecall;
        CData/*6:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__opcode;
        CData/*4:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_rs1;
        CData/*4:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_rs2;
        CData/*4:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__EX_MEM_rd;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_EX_mem_read;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_ctrl_is_ecall;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__PC_Write;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__IF_ID_Write;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_CtrlUnitMux_sel;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs1;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs2;
        CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT__stall;
        CData/*6:0*/ top__DOT__cpu__DOT__imm_gen__DOT__op;
        CData/*0:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__ctrl_alu_op;
        CData/*7:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__alu_op;
        CData/*6:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode;
        CData/*2:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3;
        CData/*0:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__Instr30;
        CData/*6:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct7;
        CData/*4:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__ID_EX_rs1;
        CData/*4:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__ID_EX_rs2;
        CData/*4:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__EX_MEM_rd;
        CData/*4:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__MEM_WB_rd;
        CData/*0:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__EX_MEM_reg_write;
        CData/*0:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__MEM_WB_reg_write;
        CData/*0:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__ID_ctrl_is_ecall;
        CData/*1:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__forward_a;
        CData/*1:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__forward_b;
        CData/*0:0*/ top__DOT__cpu__DOT__data_fw_unit__DOT__forward_ecall;
        CData/*1:0*/ top__DOT__cpu__DOT__DataforwardA__DOT__sel;
        CData/*1:0*/ top__DOT__cpu__DOT__DataforwardB__DOT__sel;
        CData/*0:0*/ top__DOT__cpu__DOT__ALU_in2_mux__DOT__sel;
        CData/*7:0*/ top__DOT__cpu__DOT__alu__DOT__alu_op;
        CData/*0:0*/ top__DOT__cpu__DOT__alu__DOT__alu_bcond;
        CData/*0:0*/ top__DOT__cpu__DOT__dmem__DOT__reset;
        CData/*0:0*/ top__DOT__cpu__DOT__dmem__DOT__clk;
        CData/*0:0*/ top__DOT__cpu__DOT__dmem__DOT__mem_read;
        CData/*0:0*/ top__DOT__cpu__DOT__dmem__DOT__mem_write;
        CData/*0:0*/ top__DOT__cpu__DOT__WB_mux__DOT__sel;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VicoFirstIteration;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clk__0;
        CData/*0:0*/ __VactDidInit;
        CData/*0:0*/ __VactContinue;
        IData/*31:0*/ top__DOT__cpu__DOT__IF_ID_inst;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_EX_rs1_data;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_EX_rs2_data;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_EX_imm;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_EX_ALU_ctrl_unit_input;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_MEM_alu_out;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_MEM_dmem_data;
        IData/*31:0*/ top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_1;
    };
    struct {
        IData/*31:0*/ top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_2;
        IData/*31:0*/ top__DOT__cpu__DOT__IF_current_pc_plus_4;
        IData/*31:0*/ top__DOT__cpu__DOT__IF_next_pc;
        IData/*31:0*/ top__DOT__cpu__DOT__IF_current_pc;
        IData/*31:0*/ top__DOT__cpu__DOT__IF_instr;
        IData/*31:0*/ top__DOT__cpu__DOT__IF_ID_PC;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_EX_PC;
        IData/*31:0*/ top__DOT__cpu__DOT__WB_ID_rd_din;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_rs1_dout;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_rs2_dout;
        IData/*31:0*/ top__DOT__cpu__DOT__ID_imm_out;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_branch_addr;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_alu_in1;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_alu_in2;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_alu_src2;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_alu_result;
        IData/*31:0*/ top__DOT__cpu__DOT__EX_MEM_branch_addr;
        IData/*31:0*/ top__DOT__cpu__DOT__MEM_dout;
        IData/*31:0*/ top__DOT__cpu__DOT__PC_mux__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__PC_mux__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__PC_mux__DOT__out;
        IData/*31:0*/ top__DOT__cpu__DOT__pc__DOT__next_pc;
        IData/*31:0*/ top__DOT__cpu__DOT__pc__DOT__current_pc;
        IData/*31:0*/ top__DOT__cpu__DOT__pc_adder__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__pc_adder__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__pc_adder__DOT__out;
        IData/*31:0*/ top__DOT__cpu__DOT__imem__DOT__addr;
        IData/*31:0*/ top__DOT__cpu__DOT__imem__DOT__dout;
        IData/*31:0*/ top__DOT__cpu__DOT__imem__DOT__i;
        IData/*31:0*/ top__DOT__cpu__DOT__imem__DOT__imem_addr;
        IData/*31:0*/ top__DOT__cpu__DOT__reg_file__DOT__rd_din;
        IData/*31:0*/ top__DOT__cpu__DOT__reg_file__DOT__rs1_dout;
        IData/*31:0*/ top__DOT__cpu__DOT__reg_file__DOT__rs2_dout;
        IData/*31:0*/ top__DOT__cpu__DOT__reg_file__DOT__i;
        IData/*31:0*/ top__DOT__cpu__DOT__imm_gen__DOT__Instr;
        IData/*31:0*/ top__DOT__cpu__DOT__imm_gen__DOT__imm_gen_out;
        IData/*31:0*/ top__DOT__cpu__DOT__branch_adder__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__branch_adder__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__branch_adder__DOT__out;
        IData/*31:0*/ top__DOT__cpu__DOT__alu_ctrl_unit__DOT__instr;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardA__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardA__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardA__DOT__in2;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardA__DOT__in3;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardA__DOT__out;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardB__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardB__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardB__DOT__in2;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardB__DOT__in3;
        IData/*31:0*/ top__DOT__cpu__DOT__DataforwardB__DOT__out;
        IData/*31:0*/ top__DOT__cpu__DOT__ALU_in2_mux__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__ALU_in2_mux__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__ALU_in2_mux__DOT__out;
        IData/*31:0*/ top__DOT__cpu__DOT__alu__DOT__alu_in_1;
        IData/*31:0*/ top__DOT__cpu__DOT__alu__DOT__alu_in_2;
        IData/*31:0*/ top__DOT__cpu__DOT__alu__DOT__alu_result;
        IData/*31:0*/ top__DOT__cpu__DOT__dmem__DOT__addr;
        IData/*31:0*/ top__DOT__cpu__DOT__dmem__DOT__din;
        IData/*31:0*/ top__DOT__cpu__DOT__dmem__DOT__dout;
        IData/*31:0*/ top__DOT__cpu__DOT__dmem__DOT__i;
        IData/*31:0*/ top__DOT__cpu__DOT__dmem__DOT__dmem_addr;
        IData/*31:0*/ top__DOT__cpu__DOT__WB_mux__DOT__in0;
        IData/*31:0*/ top__DOT__cpu__DOT__WB_mux__DOT__in1;
        IData/*31:0*/ top__DOT__cpu__DOT__WB_mux__DOT__out;
    };
    struct {
        IData/*31:0*/ __Vdly__top__DOT__cpu__DOT__IF_ID_inst;
        IData/*31:0*/ __VactIterCount;
        VL_OUT(print_reg[32],31,0);
        VlUnpacked<IData/*31:0*/, 32> top__DOT__print_reg;
        VlUnpacked<IData/*31:0*/, 32> top__DOT__cpu__DOT__print_reg;
        VlUnpacked<IData/*31:0*/, 1024> top__DOT__cpu__DOT__imem__DOT__mem;
        VlUnpacked<IData/*31:0*/, 32> top__DOT__cpu__DOT__reg_file__DOT__print_reg;
        VlUnpacked<IData/*31:0*/, 32> top__DOT__cpu__DOT__reg_file__DOT__rf;
        VlUnpacked<IData/*31:0*/, 16384> top__DOT__cpu__DOT__dmem__DOT__mem;
    };
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vtop__Syms* const vlSymsp;

    // PARAMETERS
    static constexpr IData/*31:0*/ top__DOT__cpu__DOT__imem__DOT__MEM_DEPTH = 0x00000400U;
    static constexpr IData/*31:0*/ top__DOT__cpu__DOT__dmem__DOT__MEM_DEPTH = 0x00004000U;

    // CONSTRUCTORS
    Vtop___024root(Vtop__Syms* symsp, const char* v__name);
    ~Vtop___024root();
    VL_UNCOPYABLE(Vtop___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
