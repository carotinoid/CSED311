// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop__pch.h"
#include "Vtop___024root.h"

VL_ATTR_COLD void Vtop___024root___eval_static(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_static\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vtop___024root___eval_initial__TOP(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_initial(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_initial\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtop___024root___eval_initial__TOP(vlSelf);
    vlSelfRef.__Vtrigprevexpr___TOP__clk__0 = vlSelfRef.clk;
}

VL_ATTR_COLD void Vtop___024root___eval_initial__TOP(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_initial__TOP\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_alu_op = 0U;
    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
    vlSelfRef.top__DOT__cpu__DOT__pc_adder__DOT__in1 = 4U;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardA__DOT__in3 = 0U;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardB__DOT__in3 = 0U;
}

VL_ATTR_COLD void Vtop___024root___eval_final(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_final\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__stl(Vtop___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vtop___024root___eval_phase__stl(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_settle(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_settle\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY(((0x64U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vtop___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("top.v", 4, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vtop___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__stl(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__stl\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtop___024root___stl_sequent__TOP__0(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_stl(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_stl\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        Vtop___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD void Vtop___024root___stl_sequent__TOP__0(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___stl_sequent__TOP__0\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_1;
    top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_1 = 0;
    CData/*0:0*/ top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_2;
    top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_2 = 0;
    CData/*0:0*/ top__DOT__cpu__DOT__DataforwardA__DOT____VdfgRegularize_hf9757099_0_0;
    top__DOT__cpu__DOT__DataforwardA__DOT____VdfgRegularize_hf9757099_0_0 = 0;
    CData/*0:0*/ top__DOT__cpu__DOT__DataforwardB__DOT____VdfgRegularize_hf9757099_0_0;
    top__DOT__cpu__DOT__DataforwardB__DOT____VdfgRegularize_hf9757099_0_0 = 0;
    CData/*0:0*/ __VdfgRegularize_hd87f99a1_0_0;
    __VdfgRegularize_hd87f99a1_0_0 = 0;
    CData/*0:0*/ __VdfgRegularize_hd87f99a1_0_1;
    __VdfgRegularize_hd87f99a1_0_1 = 0;
    CData/*0:0*/ __VdfgRegularize_hd87f99a1_0_2;
    __VdfgRegularize_hd87f99a1_0_2 = 0;
    CData/*0:0*/ __VdfgRegularize_hd87f99a1_0_3;
    __VdfgRegularize_hd87f99a1_0_3 = 0;
    // Body
    vlSelfRef.top__DOT__cpu__DOT__PC_mux__DOT__in1 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_branch_addr;
    vlSelfRef.top__DOT__cpu__DOT__pc__DOT__current_pc 
        = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc;
    vlSelfRef.top__DOT__cpu__DOT__pc_adder__DOT__in0 
        = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc;
    vlSelfRef.top__DOT__cpu__DOT__imem__DOT__addr = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc;
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rd 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_rd;
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__write_enable 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_reg_write;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__alu_op 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_alu_op;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__EX_MEM_rd 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_rd;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_EX_mem_read 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_mem_read;
    vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__Instr 
        = vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst;
    vlSelfRef.top__DOT__cpu__DOT__branch_adder__DOT__in0 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_PC;
    vlSelfRef.top__DOT__cpu__DOT__branch_adder__DOT__in1 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_imm;
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__instr 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_ALU_ctrl_unit_input;
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__ctrl_alu_op 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_ctrl_alu_op;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__ID_EX_rs1 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__ID_EX_rs2 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__EX_MEM_rd 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_rd;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__MEM_WB_rd 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_rd;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__EX_MEM_reg_write 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_reg_write;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__MEM_WB_reg_write 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_reg_write;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardA__DOT__in0 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1_data;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardA__DOT__in2 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardB__DOT__in0 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2_data;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardB__DOT__in2 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out;
    vlSelfRef.top__DOT__cpu__DOT__ALU_in2_mux__DOT__in1 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_imm;
    vlSelfRef.top__DOT__cpu__DOT__ALU_in2_mux__DOT__sel 
        = vlSelfRef.top__DOT__cpu__DOT__ID_EX_alu_src;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__addr = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__din = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_dmem_data;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__mem_read 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_mem_read;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__mem_write 
        = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_mem_write;
    vlSelfRef.top__DOT__cpu__DOT__WB_mux__DOT__in0 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_1;
    vlSelfRef.top__DOT__cpu__DOT__WB_mux__DOT__in1 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_2;
    vlSelfRef.top__DOT__cpu__DOT__WB_mux__DOT__sel 
        = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_mem_to_reg;
    vlSelfRef.top__DOT__cpu__DOT__EX_branch_addr = 
        (vlSelfRef.top__DOT__cpu__DOT__ID_EX_PC + vlSelfRef.top__DOT__cpu__DOT__ID_EX_imm);
    vlSelfRef.is_halted = vlSelfRef.top__DOT__cpu__DOT__MEM_WB_is_halted;
    vlSelfRef.top__DOT__cpu__DOT__imem__DOT__imem_addr 
        = VL_SHIFTR_III(32,32,32, vlSelfRef.top__DOT__cpu__DOT__IF_current_pc, 2U);
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__dmem_addr 
        = VL_SHIFTR_III(32,32,32, vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out, 2U);
    vlSelfRef.top__DOT__reset = vlSelfRef.reset;
    vlSelfRef.top__DOT__clk = vlSelfRef.clk;
    vlSelfRef.top__DOT__cpu__DOT__IF_PCsrc = ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_bcond) 
                                              & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_is_branch));
    vlSelfRef.top__DOT__cpu__DOT__IF_current_pc_plus_4 
        = ((IData)(4U) + vlSelfRef.top__DOT__cpu__DOT__IF_current_pc);
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode 
        = (0x7fU & vlSelfRef.top__DOT__cpu__DOT__ID_EX_ALU_ctrl_unit_input);
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3 
        = (7U & (vlSelfRef.top__DOT__cpu__DOT__ID_EX_ALU_ctrl_unit_input 
                 >> 0xcU));
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__Instr30 
        = (1U & (vlSelfRef.top__DOT__cpu__DOT__ID_EX_ALU_ctrl_unit_input 
                 >> 0x1eU));
    __VdfgRegularize_hd87f99a1_0_1 = ((0U != (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1)) 
                                      & (((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1) 
                                          == (IData)(vlSelfRef.top__DOT__cpu__DOT__MEM_WB_rd)) 
                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__MEM_WB_reg_write)));
    __VdfgRegularize_hd87f99a1_0_3 = ((0U != (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2)) 
                                      & (((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2) 
                                          == (IData)(vlSelfRef.top__DOT__cpu__DOT__MEM_WB_rd)) 
                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__MEM_WB_reg_write)));
    __VdfgRegularize_hd87f99a1_0_0 = ((0U != (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1)) 
                                      & (((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_rd) 
                                          == (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1)) 
                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_reg_write)));
    vlSelfRef.top__DOT__cpu__DOT__ID_rs2 = (0x1fU & 
                                            (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                             >> 0x14U));
    vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din = ((IData)(vlSelfRef.top__DOT__cpu__DOT__MEM_WB_mem_to_reg)
                                                   ? vlSelfRef.top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_2
                                                   : vlSelfRef.top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_1);
    __VdfgRegularize_hd87f99a1_0_2 = ((0U != (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2)) 
                                      & (((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_rd) 
                                          == (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2)) 
                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_reg_write)));
    vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op 
        = (0x7fU & vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst);
    vlSelfRef.print_reg[0U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0U];
    vlSelfRef.print_reg[1U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [1U];
    vlSelfRef.print_reg[2U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [2U];
    vlSelfRef.print_reg[3U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [3U];
    vlSelfRef.print_reg[4U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [4U];
    vlSelfRef.print_reg[5U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [5U];
    vlSelfRef.print_reg[6U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [6U];
    vlSelfRef.print_reg[7U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [7U];
    vlSelfRef.print_reg[8U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [8U];
    vlSelfRef.print_reg[9U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [9U];
    vlSelfRef.print_reg[0xaU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0xaU];
    vlSelfRef.print_reg[0xbU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0xbU];
    vlSelfRef.print_reg[0xcU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0xcU];
    vlSelfRef.print_reg[0xdU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0xdU];
    vlSelfRef.print_reg[0xeU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0xeU];
    vlSelfRef.print_reg[0xfU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0xfU];
    vlSelfRef.print_reg[0x10U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x10U];
    vlSelfRef.print_reg[0x11U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x11U];
    vlSelfRef.print_reg[0x12U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x12U];
    vlSelfRef.print_reg[0x13U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x13U];
    vlSelfRef.print_reg[0x14U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x14U];
    vlSelfRef.print_reg[0x15U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x15U];
    vlSelfRef.print_reg[0x16U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x16U];
    vlSelfRef.print_reg[0x17U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x17U];
    vlSelfRef.print_reg[0x18U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x18U];
    vlSelfRef.print_reg[0x19U] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x19U];
    vlSelfRef.print_reg[0x1aU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x1aU];
    vlSelfRef.print_reg[0x1bU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x1bU];
    vlSelfRef.print_reg[0x1cU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x1cU];
    vlSelfRef.print_reg[0x1dU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x1dU];
    vlSelfRef.print_reg[0x1eU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x1eU];
    vlSelfRef.print_reg[0x1fU] = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [0x1fU];
    vlSelfRef.top__DOT__cpu__DOT__branch_adder__DOT__out 
        = vlSelfRef.top__DOT__cpu__DOT__EX_branch_addr;
    vlSelfRef.top__DOT__is_halted = vlSelfRef.is_halted;
    vlSelfRef.top__DOT__cpu__DOT__IF_instr = vlSelfRef.top__DOT__cpu__DOT__imem__DOT__mem
        [(0x3ffU & vlSelfRef.top__DOT__cpu__DOT__imem__DOT__imem_addr)];
    vlSelfRef.top__DOT__cpu__DOT__MEM_dout = ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_mem_read)
                                               ? vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__mem
                                              [(0x3fffU 
                                                & vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__dmem_addr)]
                                               : 0U);
    vlSelfRef.top__DOT__cpu__DOT__reset = vlSelfRef.top__DOT__reset;
    vlSelfRef.top__DOT__cpu__DOT__clk = vlSelfRef.top__DOT__clk;
    if (vlSelfRef.top__DOT__cpu__DOT__IF_PCsrc) {
        vlSelfRef.top__DOT__cpu__DOT__PC_mux__DOT__sel = 1U;
        vlSelfRef.top__DOT__cpu__DOT__PC_mux__DOT__in0 
            = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc_plus_4;
        vlSelfRef.top__DOT__cpu__DOT__pc_adder__DOT__out 
            = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc_plus_4;
        vlSelfRef.top__DOT__cpu__DOT__IF_next_pc = vlSelfRef.top__DOT__cpu__DOT__EX_MEM_branch_addr;
    } else {
        vlSelfRef.top__DOT__cpu__DOT__PC_mux__DOT__sel = 0U;
        vlSelfRef.top__DOT__cpu__DOT__PC_mux__DOT__in0 
            = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc_plus_4;
        vlSelfRef.top__DOT__cpu__DOT__pc_adder__DOT__out 
            = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc_plus_4;
        vlSelfRef.top__DOT__cpu__DOT__IF_next_pc = vlSelfRef.top__DOT__cpu__DOT__IF_current_pc_plus_4;
    }
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct7 
        = ((IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__Instr30) 
           << 5U);
    vlSelfRef.top__DOT__cpu__DOT__EX_alu_op = ((0x40U 
                                                & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                ? (
                                                   (0x20U 
                                                    & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                    ? 
                                                   ((0x10U 
                                                     & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                     ? 0U
                                                     : 
                                                    ((8U 
                                                      & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                      ? 0U
                                                      : 
                                                     ((4U 
                                                       & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                       ? 0U
                                                       : 
                                                      ((2U 
                                                        & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                         ? 
                                                        ((4U 
                                                          & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                          ? 
                                                         ((2U 
                                                           & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                           ? 8U
                                                           : 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 0xbU
                                                            : 0xaU))
                                                          : 
                                                         ((2U 
                                                           & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                           ? 8U
                                                           : 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 9U
                                                            : 8U)))
                                                         : 0U)
                                                        : 0U))))
                                                    : 0U)
                                                : (
                                                   (0x20U 
                                                    & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                    ? 
                                                   ((0x10U 
                                                     & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                     ? 
                                                    ((8U 
                                                      & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                      ? 0U
                                                      : 
                                                     ((4U 
                                                       & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                       ? 0U
                                                       : 
                                                      ((2U 
                                                        & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                         ? 
                                                        ((4U 
                                                          & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                          ? 
                                                         ((2U 
                                                           & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                           ? 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 5U
                                                            : 4U)
                                                           : 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 6U
                                                            : 3U))
                                                          : 
                                                         ((2U 
                                                           & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                           ? 0U
                                                           : 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 2U
                                                            : 
                                                           ((IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__Instr30)
                                                             ? 1U
                                                             : 0U))))
                                                         : 0U)
                                                        : 0U)))
                                                     : 0U)
                                                    : 
                                                   ((0x10U 
                                                     & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                     ? 
                                                    ((8U 
                                                      & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                      ? 0U
                                                      : 
                                                     ((4U 
                                                       & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                       ? 0U
                                                       : 
                                                      ((2U 
                                                        & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode))
                                                         ? 
                                                        ((4U 
                                                          & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                          ? 
                                                         ((2U 
                                                           & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                           ? 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 5U
                                                            : 4U)
                                                           : 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 6U
                                                            : 3U))
                                                          : 
                                                         ((2U 
                                                           & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                           ? 0U
                                                           : 
                                                          ((1U 
                                                            & (IData)(vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3))
                                                            ? 2U
                                                            : 0U)))
                                                         : 0U)
                                                        : 0U)))
                                                     : 0U)));
    top__DOT__cpu__DOT__DataforwardA__DOT____VdfgRegularize_hf9757099_0_0 
        = ((~ (IData)(__VdfgRegularize_hd87f99a1_0_0)) 
           & (IData)(__VdfgRegularize_hd87f99a1_0_1));
    if (__VdfgRegularize_hd87f99a1_0_0) {
        vlSelfRef.top__DOT__cpu__DOT__forward_a = 2U;
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 = 
            ((IData)(top__DOT__cpu__DOT__DataforwardA__DOT____VdfgRegularize_hf9757099_0_0)
              ? 0U : vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out);
    } else {
        vlSelfRef.top__DOT__cpu__DOT__forward_a = ((IData)(__VdfgRegularize_hd87f99a1_0_1)
                                                    ? 1U
                                                    : 0U);
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 = 
            ((IData)(top__DOT__cpu__DOT__DataforwardA__DOT____VdfgRegularize_hf9757099_0_0)
              ? vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din
              : vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs1_data);
    }
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rs2 
        = vlSelfRef.top__DOT__cpu__DOT__ID_rs2;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_rs2 
        = vlSelfRef.top__DOT__cpu__DOT__ID_rs2;
    vlSelfRef.top__DOT__cpu__DOT__ID_rs2_dout = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [vlSelfRef.top__DOT__cpu__DOT__ID_rs2];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rd_din 
        = vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardA__DOT__in1 
        = vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardB__DOT__in1 
        = vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din;
    vlSelfRef.top__DOT__cpu__DOT__WB_mux__DOT__out 
        = vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din;
    top__DOT__cpu__DOT__DataforwardB__DOT____VdfgRegularize_hf9757099_0_0 
        = ((~ (IData)(__VdfgRegularize_hd87f99a1_0_2)) 
           & (IData)(__VdfgRegularize_hd87f99a1_0_3));
    if (__VdfgRegularize_hd87f99a1_0_2) {
        vlSelfRef.top__DOT__cpu__DOT__forward_b = 2U;
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_src2 = 
            ((IData)(top__DOT__cpu__DOT__DataforwardB__DOT____VdfgRegularize_hf9757099_0_0)
              ? 0U : vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out);
    } else {
        vlSelfRef.top__DOT__cpu__DOT__forward_b = ((IData)(__VdfgRegularize_hd87f99a1_0_3)
                                                    ? 1U
                                                    : 0U);
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_src2 = 
            ((IData)(top__DOT__cpu__DOT__DataforwardB__DOT____VdfgRegularize_hf9757099_0_0)
              ? vlSelfRef.top__DOT__cpu__DOT__WB_ID_rd_din
              : vlSelfRef.top__DOT__cpu__DOT__ID_EX_rs2_data);
    }
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__Instr 
        = vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__opcode 
        = vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op;
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_alu_src = 
        ((0x33U != (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)) 
         & (0x63U != (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)));
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_write_enable 
        = ((0x23U != (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)) 
           & (0x63U != (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)));
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_pc_to_reg 
        = ((0x6fU == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)) 
           | (0x67U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)));
    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
    if ((0x40U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
        if ((0x20U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
            if ((0x10U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
            } else if ((8U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                if ((4U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                    if ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                        if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                = ((0xfff00001U & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                                   | ((0xff000U & vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst) 
                                      | ((0x800U & 
                                          (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                           >> 9U)) 
                                         | (0x7feU 
                                            & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                               >> 0x14U)))));
                            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                = ((0xffefffffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                                   | (0x100000U & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                                   >> 0xbU)));
                            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                = ((0x1fffffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                                   | ((- (IData)((1U 
                                                  & (vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                                     >> 0x14U)))) 
                                      << 0x15U));
                        } else {
                            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
                        }
                    } else {
                        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
                    }
                } else {
                    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
                }
            } else if ((4U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                if ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                    if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                            = ((0xfffff000U & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                               | (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                  >> 0x14U));
                        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                            = ((0xfffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                               | ((- (IData)((1U & 
                                              (vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                               >> 0xbU)))) 
                                  << 0xcU));
                    } else {
                        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
                    }
                } else {
                    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
                }
            } else if ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                        = ((0xfffff001U & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                           | ((0x800U & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                         << 4U)) | 
                              ((0x7e0U & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                          >> 0x14U)) 
                               | (0x1eU & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                           >> 7U)))));
                    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                        = ((0xffffefffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                           | (0x1000U & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                         >> 0x13U)));
                    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                        = ((0x1fffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                           | ((- (IData)((1U & (vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                                >> 0xcU)))) 
                              << 0xdU));
                } else {
                    vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
                }
            } else {
                vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
            }
        } else {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
        }
    } else if ((0x20U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
        if ((0x10U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
        } else if ((8U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
        } else if ((4U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
        } else if ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
            if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
                vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                    = ((0xfffff000U & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                       | ((0xfe0U & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                     >> 0x14U)) | (0x1fU 
                                                   & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                                      >> 7U))));
                vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                    = ((0xfffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                       | ((- (IData)((1U & (vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                            >> 0xbU)))) 
                          << 0xcU));
            } else {
                vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
            }
        } else {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
        }
    } else if ((8U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
    } else if ((4U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
    } else if ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
        if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op))) {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                = ((0xfffff000U & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                   | (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                      >> 0x14U));
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                = ((0xfffU & vlSelfRef.top__DOT__cpu__DOT__ID_imm_out) 
                   | ((- (IData)((1U & (vlSelfRef.top__DOT__cpu__DOT__ID_imm_out 
                                        >> 0xbU)))) 
                      << 0xcU));
        } else {
            vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
        }
    } else {
        vlSelfRef.top__DOT__cpu__DOT__ID_imm_out = 0U;
    }
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_read 
        = (3U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op));
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_write 
        = (0x23U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op));
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_branch = 
        (0x63U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op));
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_is_ecall 
        = (0x73U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op));
    vlSelfRef.top__DOT__print_reg[0U] = vlSelfRef.print_reg
        [0U];
    vlSelfRef.top__DOT__print_reg[1U] = vlSelfRef.print_reg
        [1U];
    vlSelfRef.top__DOT__print_reg[2U] = vlSelfRef.print_reg
        [2U];
    vlSelfRef.top__DOT__print_reg[3U] = vlSelfRef.print_reg
        [3U];
    vlSelfRef.top__DOT__print_reg[4U] = vlSelfRef.print_reg
        [4U];
    vlSelfRef.top__DOT__print_reg[5U] = vlSelfRef.print_reg
        [5U];
    vlSelfRef.top__DOT__print_reg[6U] = vlSelfRef.print_reg
        [6U];
    vlSelfRef.top__DOT__print_reg[7U] = vlSelfRef.print_reg
        [7U];
    vlSelfRef.top__DOT__print_reg[8U] = vlSelfRef.print_reg
        [8U];
    vlSelfRef.top__DOT__print_reg[9U] = vlSelfRef.print_reg
        [9U];
    vlSelfRef.top__DOT__print_reg[0xaU] = vlSelfRef.print_reg
        [0xaU];
    vlSelfRef.top__DOT__print_reg[0xbU] = vlSelfRef.print_reg
        [0xbU];
    vlSelfRef.top__DOT__print_reg[0xcU] = vlSelfRef.print_reg
        [0xcU];
    vlSelfRef.top__DOT__print_reg[0xdU] = vlSelfRef.print_reg
        [0xdU];
    vlSelfRef.top__DOT__print_reg[0xeU] = vlSelfRef.print_reg
        [0xeU];
    vlSelfRef.top__DOT__print_reg[0xfU] = vlSelfRef.print_reg
        [0xfU];
    vlSelfRef.top__DOT__print_reg[0x10U] = vlSelfRef.print_reg
        [0x10U];
    vlSelfRef.top__DOT__print_reg[0x11U] = vlSelfRef.print_reg
        [0x11U];
    vlSelfRef.top__DOT__print_reg[0x12U] = vlSelfRef.print_reg
        [0x12U];
    vlSelfRef.top__DOT__print_reg[0x13U] = vlSelfRef.print_reg
        [0x13U];
    vlSelfRef.top__DOT__print_reg[0x14U] = vlSelfRef.print_reg
        [0x14U];
    vlSelfRef.top__DOT__print_reg[0x15U] = vlSelfRef.print_reg
        [0x15U];
    vlSelfRef.top__DOT__print_reg[0x16U] = vlSelfRef.print_reg
        [0x16U];
    vlSelfRef.top__DOT__print_reg[0x17U] = vlSelfRef.print_reg
        [0x17U];
    vlSelfRef.top__DOT__print_reg[0x18U] = vlSelfRef.print_reg
        [0x18U];
    vlSelfRef.top__DOT__print_reg[0x19U] = vlSelfRef.print_reg
        [0x19U];
    vlSelfRef.top__DOT__print_reg[0x1aU] = vlSelfRef.print_reg
        [0x1aU];
    vlSelfRef.top__DOT__print_reg[0x1bU] = vlSelfRef.print_reg
        [0x1bU];
    vlSelfRef.top__DOT__print_reg[0x1cU] = vlSelfRef.print_reg
        [0x1cU];
    vlSelfRef.top__DOT__print_reg[0x1dU] = vlSelfRef.print_reg
        [0x1dU];
    vlSelfRef.top__DOT__print_reg[0x1eU] = vlSelfRef.print_reg
        [0x1eU];
    vlSelfRef.top__DOT__print_reg[0x1fU] = vlSelfRef.print_reg
        [0x1fU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0U] = vlSelfRef.print_reg
        [0U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[1U] = vlSelfRef.print_reg
        [1U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[2U] = vlSelfRef.print_reg
        [2U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[3U] = vlSelfRef.print_reg
        [3U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[4U] = vlSelfRef.print_reg
        [4U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[5U] = vlSelfRef.print_reg
        [5U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[6U] = vlSelfRef.print_reg
        [6U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[7U] = vlSelfRef.print_reg
        [7U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[8U] = vlSelfRef.print_reg
        [8U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[9U] = vlSelfRef.print_reg
        [9U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0xaU] = 
        vlSelfRef.print_reg[0xaU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0xbU] = 
        vlSelfRef.print_reg[0xbU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0xcU] = 
        vlSelfRef.print_reg[0xcU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0xdU] = 
        vlSelfRef.print_reg[0xdU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0xeU] = 
        vlSelfRef.print_reg[0xeU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0xfU] = 
        vlSelfRef.print_reg[0xfU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x10U] 
        = vlSelfRef.print_reg[0x10U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x11U] 
        = vlSelfRef.print_reg[0x11U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x12U] 
        = vlSelfRef.print_reg[0x12U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x13U] 
        = vlSelfRef.print_reg[0x13U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x14U] 
        = vlSelfRef.print_reg[0x14U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x15U] 
        = vlSelfRef.print_reg[0x15U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x16U] 
        = vlSelfRef.print_reg[0x16U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x17U] 
        = vlSelfRef.print_reg[0x17U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x18U] 
        = vlSelfRef.print_reg[0x18U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x19U] 
        = vlSelfRef.print_reg[0x19U];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x1aU] 
        = vlSelfRef.print_reg[0x1aU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x1bU] 
        = vlSelfRef.print_reg[0x1bU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x1cU] 
        = vlSelfRef.print_reg[0x1cU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x1dU] 
        = vlSelfRef.print_reg[0x1dU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x1eU] 
        = vlSelfRef.print_reg[0x1eU];
    vlSelfRef.top__DOT__cpu__DOT__print_reg[0x1fU] 
        = vlSelfRef.print_reg[0x1fU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0U] 
        = vlSelfRef.print_reg[0U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[1U] 
        = vlSelfRef.print_reg[1U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[2U] 
        = vlSelfRef.print_reg[2U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[3U] 
        = vlSelfRef.print_reg[3U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[4U] 
        = vlSelfRef.print_reg[4U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[5U] 
        = vlSelfRef.print_reg[5U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[6U] 
        = vlSelfRef.print_reg[6U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[7U] 
        = vlSelfRef.print_reg[7U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[8U] 
        = vlSelfRef.print_reg[8U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[9U] 
        = vlSelfRef.print_reg[9U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0xaU] 
        = vlSelfRef.print_reg[0xaU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0xbU] 
        = vlSelfRef.print_reg[0xbU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0xcU] 
        = vlSelfRef.print_reg[0xcU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0xdU] 
        = vlSelfRef.print_reg[0xdU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0xeU] 
        = vlSelfRef.print_reg[0xeU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0xfU] 
        = vlSelfRef.print_reg[0xfU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x10U] 
        = vlSelfRef.print_reg[0x10U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x11U] 
        = vlSelfRef.print_reg[0x11U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x12U] 
        = vlSelfRef.print_reg[0x12U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x13U] 
        = vlSelfRef.print_reg[0x13U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x14U] 
        = vlSelfRef.print_reg[0x14U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x15U] 
        = vlSelfRef.print_reg[0x15U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x16U] 
        = vlSelfRef.print_reg[0x16U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x17U] 
        = vlSelfRef.print_reg[0x17U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x18U] 
        = vlSelfRef.print_reg[0x18U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x19U] 
        = vlSelfRef.print_reg[0x19U];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x1aU] 
        = vlSelfRef.print_reg[0x1aU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x1bU] 
        = vlSelfRef.print_reg[0x1bU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x1cU] 
        = vlSelfRef.print_reg[0x1cU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x1dU] 
        = vlSelfRef.print_reg[0x1dU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x1eU] 
        = vlSelfRef.print_reg[0x1eU];
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__print_reg[0x1fU] 
        = vlSelfRef.print_reg[0x1fU];
    vlSelfRef.top__DOT__cpu__DOT__is_halted = vlSelfRef.top__DOT__is_halted;
    vlSelfRef.top__DOT__cpu__DOT__imem__DOT__dout = vlSelfRef.top__DOT__cpu__DOT__IF_instr;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__dout = vlSelfRef.top__DOT__cpu__DOT__MEM_dout;
    vlSelfRef.top__DOT__cpu__DOT__pc__DOT__reset = vlSelfRef.top__DOT__cpu__DOT__reset;
    vlSelfRef.top__DOT__cpu__DOT__imem__DOT__reset 
        = vlSelfRef.top__DOT__cpu__DOT__reset;
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__reset 
        = vlSelfRef.top__DOT__cpu__DOT__reset;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__reset 
        = vlSelfRef.top__DOT__cpu__DOT__reset;
    vlSelfRef.top__DOT__cpu__DOT__pc__DOT__clk = vlSelfRef.top__DOT__cpu__DOT__clk;
    vlSelfRef.top__DOT__cpu__DOT__imem__DOT__clk = vlSelfRef.top__DOT__cpu__DOT__clk;
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__clk 
        = vlSelfRef.top__DOT__cpu__DOT__clk;
    vlSelfRef.top__DOT__cpu__DOT__dmem__DOT__clk = vlSelfRef.top__DOT__cpu__DOT__clk;
    vlSelfRef.top__DOT__cpu__DOT__PC_mux__DOT__out 
        = vlSelfRef.top__DOT__cpu__DOT__IF_next_pc;
    vlSelfRef.top__DOT__cpu__DOT__pc__DOT__next_pc 
        = vlSelfRef.top__DOT__cpu__DOT__IF_next_pc;
    vlSelfRef.top__DOT__cpu__DOT__alu_ctrl_unit__DOT__alu_op 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_op;
    vlSelfRef.top__DOT__cpu__DOT__alu__DOT__alu_op 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_op;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__forward_a 
        = vlSelfRef.top__DOT__cpu__DOT__forward_a;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardA__DOT__sel 
        = vlSelfRef.top__DOT__cpu__DOT__forward_a;
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rs2_dout 
        = vlSelfRef.top__DOT__cpu__DOT__ID_rs2_dout;
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__forward_b 
        = vlSelfRef.top__DOT__cpu__DOT__forward_b;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardB__DOT__sel 
        = vlSelfRef.top__DOT__cpu__DOT__forward_b;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__ALUSrc 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_alu_src;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__RegWrite 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_write_enable;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__PCtoReg 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_pc_to_reg;
    vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__imm_gen_out 
        = vlSelfRef.top__DOT__cpu__DOT__ID_imm_out;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__MemRead 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_read;
    vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_to_reg 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_read;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__MemWrite 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_write;
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__Branch 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_branch;
    top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_2 
        = ((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_write) 
           | (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_branch));
    if (vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_is_ecall) {
        vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__is_ecall = 1U;
        vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_ctrl_is_ecall = 1U;
        vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__ID_ctrl_is_ecall = 1U;
        vlSelfRef.top__DOT__cpu__DOT__forward_ecall 
            = ((0x11U == (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_rd)) 
               & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_MEM_reg_write));
        vlSelfRef.top__DOT__cpu__DOT__ID_rs1 = 0x11U;
    } else {
        vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__is_ecall = 0U;
        vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_ctrl_is_ecall = 0U;
        vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__ID_ctrl_is_ecall = 0U;
        vlSelfRef.top__DOT__cpu__DOT__forward_ecall = 0U;
        vlSelfRef.top__DOT__cpu__DOT__ID_rs1 = (0x1fU 
                                                & (vlSelfRef.top__DOT__cpu__DOT__IF_ID_inst 
                                                   >> 0xfU));
    }
    vlSelfRef.top__DOT__cpu__DOT__DataforwardA__DOT__out 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1;
    vlSelfRef.top__DOT__cpu__DOT__alu__DOT__alu_in_1 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1;
    vlSelfRef.top__DOT__cpu__DOT__DataforwardB__DOT__out 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_src2;
    vlSelfRef.top__DOT__cpu__DOT__ALU_in2_mux__DOT__in0 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_src2;
    vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2 = ((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_alu_src)
                                                 ? vlSelfRef.top__DOT__cpu__DOT__ID_EX_imm
                                                 : vlSelfRef.top__DOT__cpu__DOT__EX_alu_src2);
    vlSelfRef.top__DOT__cpu__DOT__ctrl_unit__DOT__MemtoReg 
        = vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_to_reg;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs2 
        = ((0U != (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_rs2)) 
           & ((0x33U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)) 
              | (IData)(top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_2)));
    vlSelfRef.top__DOT__cpu__DOT__data_fw_unit__DOT__forward_ecall 
        = vlSelfRef.top__DOT__cpu__DOT__forward_ecall;
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rs1 
        = vlSelfRef.top__DOT__cpu__DOT__ID_rs1;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_rs1 
        = vlSelfRef.top__DOT__cpu__DOT__ID_rs1;
    vlSelfRef.top__DOT__cpu__DOT__ID_rs1_dout = vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
        [vlSelfRef.top__DOT__cpu__DOT__ID_rs1];
    vlSelfRef.top__DOT__cpu__DOT__ID_is_halted = ((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_is_ecall) 
                                                  & (0xaU 
                                                     == 
                                                     ((IData)(vlSelfRef.top__DOT__cpu__DOT__forward_ecall)
                                                       ? vlSelfRef.top__DOT__cpu__DOT__EX_MEM_alu_out
                                                       : 
                                                      vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rf
                                                      [vlSelfRef.top__DOT__cpu__DOT__ID_rs1])));
    top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_1 
        = ((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rd) 
           == (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_rs1));
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs1 
        = ((0U != (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_rs1)) 
           & ((0x33U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)) 
              | ((0x13U == (IData)(vlSelfRef.top__DOT__cpu__DOT__imm_gen__DOT__op)) 
                 | ((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_mem_read) 
                    | (IData)(top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_2)))));
    vlSelfRef.top__DOT__cpu__DOT__ALU_in2_mux__DOT__out 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2;
    vlSelfRef.top__DOT__cpu__DOT__alu__DOT__alu_in_2 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2;
    vlSelfRef.top__DOT__cpu__DOT__EX_alu_result = 0U;
    if ((0x80U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_result = 0U;
    } else if ((0x40U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_result = 0U;
    } else if ((0x20U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_result = 0U;
    } else if ((0x10U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_result = 0U;
    } else if ((8U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
        if ((4U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
            vlSelfRef.top__DOT__cpu__DOT__EX_alu_result = 0U;
        }
    } else {
        vlSelfRef.top__DOT__cpu__DOT__EX_alu_result 
            = ((4U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                ? ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                    ? ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                        ? VL_SHIFTR_III(32,32,32, vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1, vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)
                        : VL_SHIFTR_III(32,32,32, vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1, vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2))
                    : ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                        ? (vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                           & vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)
                        : (vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                           | vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)))
                : ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                    ? ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                        ? (vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                           ^ vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)
                        : VL_SHIFTL_III(32,32,32, vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1, vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2))
                    : ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))
                        ? (vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                           - vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)
                        : (vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                           + vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2))));
    }
    vlSelfRef.top__DOT__cpu__DOT__EX_alu_bcond = 0U;
    if ((1U & (~ ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op) 
                  >> 7U)))) {
        if ((1U & (~ ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op) 
                      >> 6U)))) {
            if ((1U & (~ ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op) 
                          >> 5U)))) {
                if ((1U & (~ ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op) 
                              >> 4U)))) {
                    if ((8U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
                        if ((1U & (~ ((IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op) 
                                      >> 2U)))) {
                            if ((2U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
                                if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
                                    if ((vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                                         >= vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)) {
                                        vlSelfRef.top__DOT__cpu__DOT__EX_alu_bcond = 1U;
                                    }
                                } else if ((vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                                            < vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)) {
                                    vlSelfRef.top__DOT__cpu__DOT__EX_alu_bcond = 1U;
                                }
                            } else if ((1U & (IData)(vlSelfRef.top__DOT__cpu__DOT__EX_alu_op))) {
                                if ((vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                                     != vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)) {
                                    vlSelfRef.top__DOT__cpu__DOT__EX_alu_bcond = 1U;
                                }
                            } else if ((vlSelfRef.top__DOT__cpu__DOT__EX_alu_in1 
                                        == vlSelfRef.top__DOT__cpu__DOT__EX_alu_in2)) {
                                vlSelfRef.top__DOT__cpu__DOT__EX_alu_bcond = 1U;
                            }
                        }
                    }
                }
            }
        }
    }
    vlSelfRef.top__DOT__cpu__DOT__reg_file__DOT__rs1_dout 
        = vlSelfRef.top__DOT__cpu__DOT__ID_rs1_dout;
    vlSelfRef.top__DOT__cpu__DOT__ID_CtrlUnitMux_sel 
        = (((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_ctrl_is_ecall) 
            & (IData)(top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_1)) 
           | ((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_mem_read) 
              & (((IData)(top__DOT__cpu__DOT__haz_detect_unit__DOT____VdfgRegularize_h5e6d19d5_0_1) 
                  & (IData)(vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs1)) 
                 | (((IData)(vlSelfRef.top__DOT__cpu__DOT__ID_EX_rd) 
                     == (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_rs2)) 
                    & (IData)(vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs2)))));
    vlSelfRef.top__DOT__cpu__DOT__alu__DOT__alu_result 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_result;
    vlSelfRef.top__DOT__cpu__DOT__alu__DOT__alu_bcond 
        = vlSelfRef.top__DOT__cpu__DOT__EX_alu_bcond;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_CtrlUnitMux_sel 
        = vlSelfRef.top__DOT__cpu__DOT__ID_CtrlUnitMux_sel;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__stall 
        = vlSelfRef.top__DOT__cpu__DOT__ID_CtrlUnitMux_sel;
    vlSelfRef.top__DOT__cpu__DOT__PC_Write = (1U & 
                                              (~ (IData)(vlSelfRef.top__DOT__cpu__DOT__ID_CtrlUnitMux_sel)));
    vlSelfRef.top__DOT__cpu__DOT__pc__DOT__PC_Write 
        = vlSelfRef.top__DOT__cpu__DOT__PC_Write;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__PC_Write 
        = vlSelfRef.top__DOT__cpu__DOT__PC_Write;
    vlSelfRef.top__DOT__cpu__DOT__IF_ID_Write = vlSelfRef.top__DOT__cpu__DOT__PC_Write;
    vlSelfRef.top__DOT__cpu__DOT__haz_detect_unit__DOT__IF_ID_Write 
        = vlSelfRef.top__DOT__cpu__DOT__IF_ID_Write;
}

VL_ATTR_COLD void Vtop___024root___eval_triggers__stl(Vtop___024root* vlSelf);

VL_ATTR_COLD bool Vtop___024root___eval_phase__stl(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__stl\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vtop___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        Vtop___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__ico(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__ico\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VicoTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        VL_DBG_MSGF("         'ico' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__act(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__act\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge clk)\n");
    }
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @( clk)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__nba(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__nba\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge clk)\n");
    }
    if ((2ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @( clk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtop___024root___ctor_var_reset(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___ctor_var_reset\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelf->reset = VL_RAND_RESET_I(1);
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->is_halted = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->print_reg[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__is_halted = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->top__DOT__print_reg[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__cpu__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__is_halted = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->top__DOT__cpu__DOT__print_reg[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__cpu__DOT__IF_ID_inst = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_ctrl_alu_op = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_alu_src = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_mem_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_mem_read = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_mem_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_rs1_data = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_rs2_data = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_imm = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_ALU_ctrl_unit_input = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_mem_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_mem_read = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_is_branch = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_mem_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_alu_out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_dmem_data = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__MEM_WB_mem_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__MEM_WB_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__MEM_WB_mem_to_reg_src_2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__IF_current_pc_plus_4 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__IF_next_pc = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__IF_PCsrc = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__IF_current_pc = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__IF_instr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__IF_ID_PC = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_PC = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_rs1 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__ID_rs2 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__WB_ID_rd_din = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_rs1_dout = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_rs2_dout = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_mem_read = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_mem_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_mem_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_alu_src = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_write_enable = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_pc_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_alu_op = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_is_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_ctrl_branch = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_is_halted = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__PC_Write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__IF_ID_Write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_CtrlUnitMux_sel = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_imm_out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ID_EX_branch = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_rs1 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__ID_EX_rs2 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__ID_EX_is_halted = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ID_EX_ctrl_is_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_branch_addr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_alu_op = VL_RAND_RESET_I(8);
    vlSelf->top__DOT__cpu__DOT__forward_a = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__cpu__DOT__forward_b = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__cpu__DOT__forward_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_alu_in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_alu_in2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_alu_src2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_alu_result = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_alu_bcond = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_bcond = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_branch_addr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__EX_MEM_is_halted = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__MEM_dout = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__MEM_WB_rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__MEM_WB_is_halted = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__PC_mux__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__PC_mux__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__PC_mux__DOT__sel = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__PC_mux__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__pc__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__pc__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__pc__DOT__next_pc = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__pc__DOT__PC_Write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__pc__DOT__current_pc = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__pc_adder__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__pc_adder__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__pc_adder__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__imem__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__imem__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__imem__DOT__addr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__imem__DOT__dout = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__imem__DOT__i = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 1024; ++__Vi0) {
        vlSelf->top__DOT__cpu__DOT__imem__DOT__mem[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__cpu__DOT__imem__DOT__imem_addr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rs1 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rs2 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rd_din = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__write_enable = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rs1_dout = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rs2_dout = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->top__DOT__cpu__DOT__reg_file__DOT__print_reg[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__cpu__DOT__reg_file__DOT__i = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->top__DOT__cpu__DOT__reg_file__DOT__rf[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__Instr = VL_RAND_RESET_I(7);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__MemRead = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__MemtoReg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__MemWrite = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__ALUSrc = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__RegWrite = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__PCtoReg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__alu_op = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__Branch = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ctrl_unit__DOT__is_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__opcode = VL_RAND_RESET_I(7);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_rs1 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_rs2 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__EX_MEM_rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_EX_mem_read = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_ctrl_is_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__PC_Write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__IF_ID_Write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__ID_CtrlUnitMux_sel = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs1 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__use_rs2 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__haz_detect_unit__DOT__stall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__imm_gen__DOT__Instr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__imm_gen__DOT__imm_gen_out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__imm_gen__DOT__op = VL_RAND_RESET_I(7);
    vlSelf->top__DOT__cpu__DOT__branch_adder__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__branch_adder__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__branch_adder__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__instr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__ctrl_alu_op = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__alu_op = VL_RAND_RESET_I(8);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__opcode = VL_RAND_RESET_I(7);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct3 = VL_RAND_RESET_I(3);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__Instr30 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__alu_ctrl_unit__DOT__funct7 = VL_RAND_RESET_I(7);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__ID_EX_rs1 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__ID_EX_rs2 = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__EX_MEM_rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__MEM_WB_rd = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__EX_MEM_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__MEM_WB_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__ID_ctrl_is_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__forward_a = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__forward_b = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__cpu__DOT__data_fw_unit__DOT__forward_ecall = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__DataforwardA__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardA__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardA__DOT__in2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardA__DOT__in3 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardA__DOT__sel = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__cpu__DOT__DataforwardA__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardB__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardB__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardB__DOT__in2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardB__DOT__in3 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__DataforwardB__DOT__sel = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__cpu__DOT__DataforwardB__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ALU_in2_mux__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ALU_in2_mux__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__ALU_in2_mux__DOT__sel = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__ALU_in2_mux__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__alu__DOT__alu_op = VL_RAND_RESET_I(8);
    vlSelf->top__DOT__cpu__DOT__alu__DOT__alu_in_1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__alu__DOT__alu_in_2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__alu__DOT__alu_result = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__alu__DOT__alu_bcond = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__addr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__din = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__mem_read = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__mem_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__dout = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__i = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 16384; ++__Vi0) {
        vlSelf->top__DOT__cpu__DOT__dmem__DOT__mem[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__cpu__DOT__dmem__DOT__dmem_addr = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__WB_mux__DOT__in0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__WB_mux__DOT__in1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__cpu__DOT__WB_mux__DOT__sel = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__cpu__DOT__WB_mux__DOT__out = VL_RAND_RESET_I(32);
    vlSelf->__Vdly__top__DOT__cpu__DOT__IF_ID_inst = VL_RAND_RESET_I(32);
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = VL_RAND_RESET_I(1);
    vlSelf->__VactDidInit = 0;
}
